<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
 */
?>
  
  <div id="nav">
    <a href="http://www.worldwidewilly.immortalkeep.com/index.html" class="homenav">Home</a>
    <a href="http://www.worldwidewilly.immortalkeep.com/resume.html" class="resumenav">R&eacute;sum&eacute;</a>
    <a href="http://www.worldwidewilly.immortalkeep.com/thoughts.html" class="thoughtsnav">Thoughts</a>
    <a href="http://www.worldwidewilly.immortalkeep.com/projects.html" class="projectsnav">Projects</a>
    <a href="http://www.worldwidewilly.immortalkeep.com/contact.html" class="contactnav">Contact</a>
    <a href="http://w3schools.com/html/lastpage.htm" class="endnav">The End</a>
  </div>