<?php
/**
 * Displays metatags for administrator backend.
 */
?>
<!-- FV Flowplayer For Wordpress ADMIN Javascript Start -->
<script type="text/javascript" src="<?php echo RELATIVE_PATH; ?>/js/jscolor/jscolor.js"></script>
<script type="text/javascript" src="<?php echo RELATIVE_PATH; ?>/flowplayer/flowplayer.min.js"></script>
<link rel="stylesheet" href="<?php echo RELATIVE_PATH; ?>/css/flowplayer.css" type="text/css" media="screen" />
<!-- FV Flowplayer For Wordpress ADMIN Javascript END -->

